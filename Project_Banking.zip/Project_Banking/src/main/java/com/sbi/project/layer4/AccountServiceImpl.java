package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Account;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.AccountRepository;
import com.sbi.project.layer3.ApplicantRepository;

@Service
public class AccountServiceImpl implements AccountService
{
		@Autowired
		AccountRepository accRepo;
		
	
			
			
			@Autowired
			ApplicantRepository appRepo;
			
			
			@Override
			public void openBankAccountService(Account account) {
				// TODO Auto-generated method stub
				accRepo.createAccount(account);
				
			}
			
			@Override
			public List<Account> getAllAccounts() {
				// TODO Auto-generated method stub
				return accRepo.findAllAccounts();
			}
		
}


package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.AccountService;
import com.sbi.project.layer4.ApplicantService;

@RestController
@RequestMapping("/accounts")
public class AccountController {
	
	@Autowired
	AccountService accserv;
	
	@Autowired
	ApplicantService appserv;
	
	@PostMapping("/add")
	public String addAccount(@RequestBody Account newAccount)
		{
			accserv.openBankAccountService(newAccount);
			return "Account Successfully Created";
		}
	
	@RequestMapping("/getallaccount")   
	public List<Account> getAllAccounts()
	{	
		return accserv.getAllAccounts();
	}
	
	
	@RequestMapping("/getallapplicant")   
	public List<Applicant> getAllApplicant()
	{	
		return appserv.getAllApplicants();
	}

}
